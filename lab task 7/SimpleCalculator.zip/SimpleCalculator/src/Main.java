// Calculator class
class Calculator {

    // Addition methods
    int add(int a, int b) {
        return a + b;
    }

    double add(double a, double b) {
        return a + b;
    }

    // Subtraction methods
    int subtract(int a, int b) {
        return a - b;
    }

    double subtract(double a, double b) {
        return a - b;
    }

    // Multiplication methods
    int multiply(int a, int b) {
        return a * b;
    }

    double multiply(double a, double b) {
        return a * b;
    }

    // Division methods
    int divide(int a, int b) {
        if (b == 0) {
            System.out.println("Cannot divide by zero!");
            return 0;
        }
        return a / b;
    }

    double divide(double a, double b) {
        if (b == 0.0) {
            System.out.println("Cannot divide by zero!");
            return 0.0;
        }
        return a / b;
    }
}

// Main class
public class Main {
    public static void main(String[] args) {

        Calculator calc = new Calculator();

        // Testing with int
        System.out.println("Int Addition: " + calc.add(10, 5));
        System.out.println("Int Subtraction: " + calc.subtract(10, 5));
        System.out.println("Int Multiplication: " + calc.multiply(10, 5));
        System.out.println("Int Division: " + calc.divide(10, 5));

        // Testing with double
        System.out.println("Double Addition: " + calc.add(10.5, 5.2));
        System.out.println("Double Subtraction: " + calc.subtract(10.5, 5.2));
        System.out.println("Double Multiplication: " + calc.multiply(10.5, 5.2));
        System.out.println("Double Division: " + calc.divide(10.5, 5.2));
    }
}
