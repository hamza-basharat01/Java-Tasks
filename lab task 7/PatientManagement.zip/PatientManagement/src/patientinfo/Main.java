package patientinfo;

// Base class
class Person {
    String personName;
    int age;

    Person(String personName, int age) {
        this.personName = personName;
        this.age = age;
    }

    void print() {
        System.out.println("Name: " + personName);
        System.out.println("Age: " + age);
    }
}

// Derived class from Person
class Patient extends Person {
    String diseaseType;
    String recommendedMedicine;

    Patient(String personName, int age, String diseaseType, String recommendedMedicine) {
        super(personName, age);
        this.diseaseType = diseaseType;
        this.recommendedMedicine = recommendedMedicine;
    }

    @Override
    void print() {
        super.print();
        System.out.println("Disease Type: " + diseaseType);
        System.out.println("Recommended Medicine: " + recommendedMedicine);
    }
}

// Further derived class from Patient
class MedicarePatient extends Patient {
    String hospitalName;
    String wardName;
    int roomNumber;

    MedicarePatient(String personName, int age, String diseaseType, String recommendedMedicine,
                    String hospitalName, String wardName, int roomNumber) {
        super(personName, age, diseaseType, recommendedMedicine);
        this.hospitalName = hospitalName;
        this.wardName = wardName;
        this.roomNumber = roomNumber;
    }

    @Override
    void print() {
        super.print();
        System.out.println("Hospital Name: " + hospitalName);
        System.out.println("Ward Name: " + wardName);
        System.out.println("Room Number: " + roomNumber);
    }
}

// Main class to test
public class Main {
    public static void main(String[] args) {
        MedicarePatient patient = new MedicarePatient(
            "Ali Khan", 45, "Flu", "Paracetamol",
            "City Hospital", "General Ward", 101
        );

        patient.print();
    }
}
